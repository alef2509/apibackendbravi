package br.com.protustecnologia.wmsprodutos.contatos.service;

import br.com.protustecnologia.wmsprodutos.contatos.api.dto.ContatoFormDTO;
import br.com.protustecnologia.wmsprodutos.contatos.model.Contato;
import br.com.protustecnologia.wmsprodutos.contatos.repository.ContatoRepository;
import br.com.protustecnologia.wmsprodutos.pessoa.api.dto.PessoaFormDTO;
import br.com.protustecnologia.wmsprodutos.pessoa.model.Pessoa;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.UUID;

@Service
@Transactional
@AllArgsConstructor
public class ContatoService {

    private final ContatoRepository repository;

    public void salvar(final ContatoFormDTO dto) {

        var contato = Contato.builder()
                .id(UUID.randomUUID().toString())
                .id_pessoa(dto.getId_pessoa())
                .nome(dto.getNome())
                .telefone(dto.getTelefone())
                .email(dto.getEmail())
                .build();
        repository.saveAndFlush(contato);
    }

    public void alterar(final ContatoFormDTO dto, final String id) {

        var contato = repository.findByIdOrThrowNotFound(id);

        contato.setNome(dto.getNome());
        contato.setEmail(dto.getEmail());
        contato.setId_pessoa(dto.getId_pessoa());
        contato.setTelefone(dto.getTelefone());

        repository.saveAndFlush(contato);
    }

    public void excluir(final String id) {

        var contato = repository.findByIdOrThrowNotFound(id);
        repository.delete(contato);
    }
}
