package br.com.protustecnologia.wmsprodutos.produto.api.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class ProdutoFormDTO {

    @NotNull
    @NotBlank
    private String codprod;
    @NotNull
    @NotBlank
    private String descricao;
    @NotNull
    @NotBlank
    private String codbarrasunidade;
    @NotNull
    @NotBlank
    private String codbarrascaixa;
    @NotNull
    @NotBlank
    private String usacontroledelote;
    @NotNull
    @NotBlank
    private String usacontroledevalidade;
    @NotNull

    private BigDecimal qtun;
    @NotNull

    private BigDecimal qtcx;
    @NotNull

    private BigDecimal valorunitario;
}
