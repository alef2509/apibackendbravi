package br.com.protustecnologia.wmsprodutos.produto.exception;

public class WMSProdutoNaoEncontradoException  extends RuntimeException {

    private static final long serialVersionUID = -6237420991197291008L;

}