package br.com.protustecnologia.wmsprodutos.produto.repository;

import br.com.protustecnologia.wmsprodutos.produto.exception.WMSProdutoNaoEncontradoException;
import br.com.protustecnologia.wmsprodutos.produto.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.LockModeType;
import java.util.Optional;


@Repository
@Transactional(readOnly = true)
public interface ProdutoRepository  extends JpaRepository<Produto, String> {

    @Override
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<Produto> findById(String id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    default Produto findByIdOrThrowNotFound(String id) {
        return findById(id).orElseThrow(WMSProdutoNaoEncontradoException::new);
    }
}


