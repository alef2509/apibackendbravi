package br.com.protustecnologia.wmsprodutos.contatos.api;


import br.com.protustecnologia.wmsprodutos.contatos.api.dto.ContatoFormDTO;
import br.com.protustecnologia.wmsprodutos.contatos.model.Contato;
import br.com.protustecnologia.wmsprodutos.contatos.repository.ContatoRepository;
import br.com.protustecnologia.wmsprodutos.contatos.service.ContatoService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.transaction.Transactional;
import javax.validation.Valid;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping(path = ContatoController.PATH, produces = { MediaType.APPLICATION_JSON_VALUE })
public class ContatoController {
    public static final String PATH = "api/contato";

    @Autowired
    private ContatoService service;

    @Autowired
    private ContatoRepository repository;

    @GetMapping("/consultar")
    public List<Contato> consultar(){
        List<Contato> registros = repository.findAll();
        return registros;
    };


    @PostMapping("/salvar")
    @Transactional
    public ResponseEntity<Void> cadastrar(@RequestBody @Valid ContatoFormDTO contatoFormDto, UriComponentsBuilder uriBuilder)
    {
        service.salvar(contatoFormDto);
        return ResponseEntity.ok().build();
    }


    @PutMapping(path = "/{id}/alterar")
    public ResponseEntity<Void> alterar(@PathVariable String id, @RequestBody ContatoFormDTO dto) {

        service.alterar(dto, id);

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping(path = "/{id}/excluir")
    public ResponseEntity<Void> excluir(@PathVariable String id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }


}
