package br.com.protustecnologia.wmsprodutos.produto.api;

import br.com.protustecnologia.wmsprodutos.produto.api.dto.ProdutoFormDTO;
import br.com.protustecnologia.wmsprodutos.produto.model.Produto;
import br.com.protustecnologia.wmsprodutos.produto.repository.ProdutoRepository;
import br.com.protustecnologia.wmsprodutos.produto.service.ProdutoService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import javax.transaction.Transactional;
import javax.validation.Valid;
import java.net.URI;

@RestController
@AllArgsConstructor
@RequestMapping(path = ProdutoController.PATH, produces = { MediaType.APPLICATION_JSON_VALUE })
public class ProdutoController {
    public static final String PATH = "api/produto";

    @Autowired
    private ProdutoRepository produtoRepository;

    @Autowired
    private ProdutoService produtoService;

    @PostMapping("/salvar")
    @Transactional

    public ResponseEntity<Void> cadastrar(@RequestBody @Valid ProdutoFormDTO produtoFormDto, UriComponentsBuilder uriBuilder)
    {
        produtoService.handle(produtoFormDto);

        return ResponseEntity.ok().build();
    }

}
