package br.com.protustecnologia.wmsprodutos.pessoa.api;

import br.com.protustecnologia.wmsprodutos.pessoa.api.dto.PessoaFormDTO;
import br.com.protustecnologia.wmsprodutos.pessoa.model.Pessoa;
import br.com.protustecnologia.wmsprodutos.pessoa.repository.PessoaRepository;
import br.com.protustecnologia.wmsprodutos.pessoa.service.PessoaService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.transaction.Transactional;
import javax.validation.Valid;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping(path = PessoaController.PATH, produces = { MediaType.APPLICATION_JSON_VALUE })
public class PessoaController {
    public static final String PATH = "api/pessoa";

    @Autowired
    private PessoaService service;

    @Autowired
    private PessoaRepository repository;

    @GetMapping("/consultar")
    public List<Pessoa> consultar(){
        List<Pessoa> registros = repository.findAll();
        return registros;
    };


    @PostMapping("/salvar")
    @Transactional
    public ResponseEntity<Void> cadastrar(@RequestBody @Valid PessoaFormDTO pessoaFormDto, UriComponentsBuilder uriBuilder)
    {
        service.salvar(pessoaFormDto);
        return ResponseEntity.ok().build();
    }


    @PutMapping(path = "/{id}/alterar")
    public ResponseEntity<Void> alterar(@PathVariable String id, @RequestBody PessoaFormDTO dto) {

        service.alterar(dto, id);

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping(path = "/{id}/excluir")
    public ResponseEntity<Void> excluir(@PathVariable String id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }



}
