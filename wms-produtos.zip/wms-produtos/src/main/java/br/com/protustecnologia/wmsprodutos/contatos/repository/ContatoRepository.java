package br.com.protustecnologia.wmsprodutos.contatos.repository;

import br.com.protustecnologia.wmsprodutos.contatos.model.Contato;
import br.com.protustecnologia.wmsprodutos.pessoa.exception.PessoaNaoEncontradoException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.LockModeType;
import java.util.Optional;


@Repository
@Transactional(readOnly = true)
public interface ContatoRepository   extends JpaRepository<Contato, String> {

    @Override
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<Contato> findById(String id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    default Contato findByIdOrThrowNotFound(String id) {
        return findById(id).orElseThrow(PessoaNaoEncontradoException::new);
    }
}
