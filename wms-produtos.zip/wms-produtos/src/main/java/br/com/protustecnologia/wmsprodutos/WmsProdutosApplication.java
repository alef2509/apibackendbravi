package br.com.protustecnologia.wmsprodutos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WmsProdutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(WmsProdutosApplication.class, args);
	}

}
