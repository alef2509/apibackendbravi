package br.com.protustecnologia.wmsprodutos.pessoa.exception;

public class PessoaNaoEncontradoException  extends RuntimeException{
    private static final long serialVersionUID = -6237420991197291008L;
}


