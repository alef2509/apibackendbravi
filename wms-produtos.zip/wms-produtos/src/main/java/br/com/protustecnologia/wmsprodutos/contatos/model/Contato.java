package br.com.protustecnologia.wmsprodutos.contatos.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@Table(name = "contato")
public class Contato {

    @Id
    private String id;

    @NotNull
    @NotBlank
    private String id_pessoa;

    @NotNull
    @NotBlank
    private String telefone;

    @NotNull
    @NotBlank
    private String nome;

    @NotNull
    @NotBlank
    private String email;
}
