package br.com.protustecnologia.wmsprodutos.contatos.api.dto;

import lombok.Data;

import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class ContatoFormDTO {

    @NotNull
    @NotBlank
    private String id_pessoa;

    @NotNull
    @NotBlank
    private String telefone;

    @NotNull
    @NotBlank
    private String nome;

    @NotNull
    @NotBlank
    private String email;
}
