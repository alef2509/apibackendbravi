package br.com.protustecnologia.wmsprodutos.pessoa.service;
import br.com.protustecnologia.wmsprodutos.pessoa.api.dto.PessoaFormDTO;
import br.com.protustecnologia.wmsprodutos.pessoa.model.Pessoa;
import br.com.protustecnologia.wmsprodutos.pessoa.repository.PessoaRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.UUID;

@Service
@Transactional
@AllArgsConstructor
public class PessoaService {

    private final PessoaRepository repository;

    public void salvar(final PessoaFormDTO dto) {

        var pessoa = Pessoa.builder()
                .id(UUID.randomUUID().toString())
                .nome(dto.getNome())
                .cpf(dto.getCpf())
                .telefone(dto.getTelefone())
                .dtnascimento(dto.getDtnascimento())
                .build();
        repository.saveAndFlush(pessoa);
    }

    public void alterar(final PessoaFormDTO dto, final String id) {

        var pessoa = repository.findByIdOrThrowNotFound(id);

        pessoa.setNome(dto.getNome());
        pessoa.setCpf(dto.getCpf());
        pessoa.setDtnascimento(dto.getDtnascimento());
        pessoa.setTelefone(dto.getTelefone());

        repository.saveAndFlush(pessoa);
    }

    public void excluir(final String id) {

        var pessoa = repository.findByIdOrThrowNotFound(id);
        repository.delete(pessoa);
    }
}
