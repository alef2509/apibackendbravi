package br.com.protustecnologia.wmsprodutos.pessoa.repository;

import br.com.protustecnologia.wmsprodutos.pessoa.exception.PessoaNaoEncontradoException;
import br.com.protustecnologia.wmsprodutos.pessoa.model.Pessoa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.LockModeType;
import java.util.Optional;

@Repository
@Transactional(readOnly = true)
public interface PessoaRepository   extends JpaRepository<Pessoa, String> {

    @Override
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<Pessoa> findById(String id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    default Pessoa findByIdOrThrowNotFound(String id) {
        return findById(id).orElseThrow(PessoaNaoEncontradoException::new);
    }
}
