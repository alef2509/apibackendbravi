package br.com.protustecnologia.wmsprodutos.produto.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.annotation.JsonIgnore;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@Table(name = "produto")
public class Produto {

    @Id
    private String id;
    @NotNull
    @NotBlank
    private String codprod;
    @NotNull
    @NotBlank
    private String descricao;
    @NotNull
    @NotBlank
    private String codbarrasunidade;
    @NotNull
    @NotBlank
    private String codbarrascaixa;
    @NotNull
    @NotBlank
    private String usacontroledelote;
    @NotNull
    @NotBlank
    private String usacontroledevalidade;

    private BigDecimal qtun;

    private BigDecimal qtcx;

    private BigDecimal valorunitario;

    private LocalDate dtcadastro;

}
