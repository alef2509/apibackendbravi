package br.com.protustecnologia.wmsprodutos.produto.service;

import br.com.protustecnologia.wmsprodutos.produto.api.dto.ProdutoFormDTO;
import br.com.protustecnologia.wmsprodutos.produto.model.Produto;
import br.com.protustecnologia.wmsprodutos.produto.repository.ProdutoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.UUID;

@Service
@Transactional
@AllArgsConstructor
public class ProdutoService {

    private final ProdutoRepository repository;

    public void handle(final ProdutoFormDTO dto) {

        var produto = Produto.builder()
                .id(UUID.randomUUID().toString())
                .codprod(dto.getCodprod())
                .descricao(dto.getDescricao())
                .codbarrascaixa(dto.getCodbarrascaixa())
                .codbarrasunidade(dto.getCodbarrasunidade())
                .usacontroledelote(dto.getUsacontroledelote())
                .valorunitario(dto.getValorunitario())
                .usacontroledevalidade(dto.getUsacontroledevalidade())
                .qtcx(dto.getQtcx())
                .qtun(dto.getQtun())
                .dtcadastro(LocalDate.now())
                .build();

        repository.saveAndFlush(produto);
    }
}
