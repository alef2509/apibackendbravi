create table pessoa (
                         id       varchar(36)     not null,
                         nome  varchar(100)     not null,
                         telefone VARCHAR(30)  NOT NULL,
                         cpf VARCHAR(15)  NOT NULL,
                         dtnascimento timestamp  NOT NULL,
                         CONSTRAINT pessoa_pkey PRIMARY KEY (id)
);