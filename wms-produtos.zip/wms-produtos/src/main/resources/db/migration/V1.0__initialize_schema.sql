create table produto (
                         id       varchar(36)     not null,
                         codprod  varchar(10)     not null,
                         descricao VARCHAR(300)  NOT NULL,
                         codbarrasunidade VARCHAR(40)  NOT NULL,
                         codbarrascaixa VARCHAR(40)  NOT NULL,
                         usacontroledelote VARCHAR(1)  NOT NULL,
                         usacontroledevalidade VARCHAR(1)  NOT NULL,
                         qtun numeric(18,6) NOT NULL,
                         qtcx numeric(18,6) NOT NULL,
                         valorunitario numeric(18,6) NOT NULL,
                         dtcadastro timestamp  NOT NULL,
                         CONSTRAINT produto_pkey PRIMARY KEY (id)
);