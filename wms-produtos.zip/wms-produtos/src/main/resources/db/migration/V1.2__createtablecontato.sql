create table contato (
                        id       varchar(36)     not null,
                        id_pessoa       varchar(36)     not null,
                        email VARCHAR(50)  NOT NULL,
                        nome VARCHAR(100)  NOT NULL,
                        telefone VARCHAR(30)  NOT NULL,
                        CONSTRAINT contato_pkey PRIMARY KEY (id)
);