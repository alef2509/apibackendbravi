package br.com.protustecnologia.wmsprodutos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WmsProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
